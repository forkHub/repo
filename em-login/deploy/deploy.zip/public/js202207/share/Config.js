//NOTE: FINAL
export var config2 = {
    namaToko: 'AuniStore',
    deskripsiToko: '',
    jmlPerHal: 25,
    tokoId: 2,
    website: 'http://warungwa.hagarden.xyz',
    footer: `<H3>Auni Store</H3>Perum Taman Melati Blok FE 07 Bojong Sari - Sawangan - Depok<br/><br/>`
};
