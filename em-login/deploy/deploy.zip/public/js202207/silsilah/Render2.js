export class Render2 {
    render() {
        return "";
    }
}
