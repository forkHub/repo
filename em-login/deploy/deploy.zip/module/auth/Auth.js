"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.auth = void 0;
const AuthCont_1 = require("./AuthCont");
const AuthSql_1 = require("./AuthSql");
const HalLogin_1 = require("./HalLogin");
const Router_1 = require("./Router");
const RouterKons_1 = require("./RouterKons");
class Auth {
    routerKons = new RouterKons_1.RouterKOns();
    router = new Router_1.Router();
    cont = new AuthCont_1.AuthCont();
    halLogin = new HalLogin_1.HalLogin();
    dao = new AuthSql_1.AuthSql();
}
exports.auth = new Auth();
