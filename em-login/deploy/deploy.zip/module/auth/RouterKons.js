"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RouterKOns = void 0;
class RouterKOns {
    //auth
    login = "/auth/login";
    logout = "/auth/logout";
}
exports.RouterKOns = RouterKOns;
