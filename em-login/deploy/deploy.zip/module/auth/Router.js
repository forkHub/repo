"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Router = void 0;
const express_1 = __importDefault(require("express"));
const Auth_1 = require("./Auth");
class Router {
    router = express_1.default.Router();
    impl() {
        this.router.get(Auth_1.auth.routerKons.login, Auth_1.auth.cont.renderLogin);
        this.router.get(Auth_1.auth.routerKons.logout, Auth_1.auth.cont.logout);
        this.router.post(Auth_1.auth.routerKons.login, Auth_1.auth.cont.login);
    }
}
exports.Router = Router;
