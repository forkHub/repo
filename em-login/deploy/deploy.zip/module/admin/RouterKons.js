"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RouterKOns = void 0;
class RouterKOns {
    //#admin
    //anggota
    static daftarAnggota = "/sm/anggota/daftar";
    static daftarAnggotaFilter = "/sm/anggota/daftar/kunci/:kunci/hal/:hal";
    static pendaftaranAnggota = "/sm/anggota/baru";
    static hapusAnggota = "/sm/anggota/hapus/:id";
    static editProfile = "/sm/anggota/:id/info/edit";
    static halEditAnggota = "/sm/anggota/:id/edit/beranda";
    //pasangan
    static editRelasi = "/sm/anggota/:id/rel/edit/:id2";
    static halCariPasangan = "/sm/anggota/:id/pasangan/tambah";
    static halCariPasanganFilter = "/sm/anggota/:id/pasangan/tambah/kunci/:kunci/hal/:hal";
    static lihatPasangan = "/sm/anggota/:id/pasangan/lihat";
    //anak
    static daftarAnak = "/sm/anggota/:id/anak/baca";
    static daftarCalonAnak = "/sm/anggota/:id/anak/tambah";
    static daftarCalonAnakFilter = "/sm/anggota/:id/anak/tambah/kunci/:kunci/hal/:hal";
    static uploadFoto = "/sm/anggota/:id/gbr/upload";
    //orang tua
    static editOrtu = "/sm/anggota/:id/ortu/edit/:id2";
    static rel_daftar = "/sm/rel/daftar";
    static rel_hapus_id = "/sm/rel/hapus/:id";
}
exports.RouterKOns = RouterKOns;
