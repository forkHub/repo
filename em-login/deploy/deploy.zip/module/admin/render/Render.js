"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Render = void 0;
const Param_1 = require("../../Param");
const AnggotaBaru_1 = require("../../admin/render/AnggotaBaru");
const DaftarAnggota_1 = require("../../admin/render/DaftarAnggota");
const EditBeranda_1 = require("../../admin/render/EditBeranda");
const EditProfileAnggota_1 = require("../../admin/render/EditProfileAnggota");
const PilihAnggotaGenerik_1 = require("./PilihAnggotaGenerik");
const Util_1 = require("../../Util");
const HalSilsilah_1 = require("../../silsilah/HalSilsilah");
const RouterKons_1 = require("../RouterKons");
class Render {
    daftarAnggota = new DaftarAnggota_1.DaftarAnggotaRenderer();
    editBeranda = new EditBeranda_1.EditBeranda();
    editProfileAnggota = new EditProfileAnggota_1.EditProfileAnggota();
    anggotaBaru = new AnggotaBaru_1.AnggotaBaru();
    pilihAnggotaGenerik = new PilihAnggotaGenerik_1.PilihAnggotaGenerik();
    silsilah = new HalSilsilah_1.HalSilsilah();
    renderCari(status, path, anggota) {
        if (!status)
            return '';
        return `
			<div class="" id="navbarSupportedContent">
				<form 
					method="get" 
					type="cari" 
					class="d-flex" 
					action="${path}"
					anggota-id="${anggota ? anggota.id : '0'}"
					>
					<input class="form-control me-2" type="search" name="cari" placeholder="Search" aria-label="Search" required>
					<button class="btn btn-outline-success" type="submit">Cari</button>
				</form>
			</div>`;
    }
    //TODO: [dev] form action upload
    renderUpload(thumb, anggota) {
        return `
			<div class='background disp-none upload-gambar padding-16'>
				<div class='box padding-8 bg-putih'>
					<div class='text-align-right'>
						<button class='btn btn-primary tutup' ${Param_1.Param.HA_KLIK} ${Param_1.Param.HA_TOGGLE}="div.upload-gambar">X</button>
					</div>

					<form 
						action="${Util_1.util.getUrl(RouterKons_1.RouterKOns.uploadFoto, [anggota.id])}"
						method="post"
						class='cont upload'
						${Param_1.Param.HA_MANUAL}
						>

						<div class="form-group">
							<label for="thumb">Gambar:</label><br/>
							<img class="img-ori disp-block" src="${thumb}"><br/>
							<input type="file">
						</div>
					
						<div class='thumb-cont disp-none'>
						</div>

						<div class='foto-cont disp-none'>
						</div>
						
						<button type='submit' class='btn btn-primary upload'>Upload</button>
					</form>
				</div>
			</div>

		`;
    }
}
exports.Render = Render;
