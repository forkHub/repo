"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Router = void 0;
const express_1 = __importDefault(require("express"));
const admin_1 = require("../admin/admin");
const Auth_1 = require("../auth/Auth");
const RouterKons_1 = require("./RouterKons");
class Router {
    router = express_1.default.Router();
    impl() {
        //#admin
        //anggota
        this.router.get(RouterKons_1.RouterKOns.daftarAnggota, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.anggota.renderDaftarAnggota);
        this.router.get(RouterKons_1.RouterKOns.daftarAnggotaFilter, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.anggota.renderDaftarAnggotaCari);
        this.router.get(RouterKons_1.RouterKOns.editProfile, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.anggota.renderEditProfile);
        this.router.get(RouterKons_1.RouterKOns.halEditAnggota, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.anggota.renderHalBerandaEdit);
        this.router.get(RouterKons_1.RouterKOns.pendaftaranAnggota, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.anggota.renderPendaftaranAnggotaBaru);
        this.router.post(RouterKons_1.RouterKOns.pendaftaranAnggota, Auth_1.auth.cont.checkAuthSession, admin_1.admin.cont.anggota.pendaftaranAnggota);
        this.router.post(RouterKons_1.RouterKOns.editProfile, Auth_1.auth.cont.checkAuthSession, admin_1.admin.cont.anggota.editProfile);
        this.router.post(RouterKons_1.RouterKOns.hapusAnggota, Auth_1.auth.cont.checkAuthSession, admin_1.admin.cont.anggota.hapus);
        //anak
        this.router.get(RouterKons_1.RouterKOns.daftarCalonAnak, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.anggota.renderDaftarCalonAnak);
        this.router.get(RouterKons_1.RouterKOns.daftarCalonAnakFilter, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.anggota.renderDaftarCalonAnakCari);
        this.router.post(RouterKons_1.RouterKOns.daftarAnak, Auth_1.auth.cont.checkAuthSession, admin_1.admin.cont.anggota.daftarAnak);
        //pasangan
        this.router.get(RouterKons_1.RouterKOns.halCariPasangan, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.relasi2.renderCariPasangan);
        this.router.get(RouterKons_1.RouterKOns.halCariPasanganFilter, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.relasi2.renderCariPasangan);
        this.router.post(RouterKons_1.RouterKOns.lihatPasangan, Auth_1.auth.cont.checkAuthGet, admin_1.admin.cont.relasi2.lihatPasangan);
        this.router.post(RouterKons_1.RouterKOns.uploadFoto, Auth_1.auth.cont.checkAuthSession, admin_1.admin.cont.anggota.upload);
        this.router.post(RouterKons_1.RouterKOns.editRelasi, Auth_1.auth.cont.checkAuthSession, admin_1.admin.cont.anggota.editRel);
        this.router.post(RouterKons_1.RouterKOns.editOrtu, Auth_1.auth.cont.checkAuthSession, admin_1.admin.cont.anggota.editOrtu);
    }
}
exports.Router = Router;
