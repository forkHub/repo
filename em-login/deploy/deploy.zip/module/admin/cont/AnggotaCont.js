"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnggotaCont = void 0;
const fs_1 = __importDefault(require("fs"));
const Util_1 = require("../../Util");
const Validator_1 = require("../../Validator");
const Config_1 = require("../../Config");
const SessionData_1 = require("../../SessionData");
const admin_1 = require("../admin");
const Kons_1 = require("../../Kons");
const RouterKons_1 = require("../RouterKons");
class AnggotaCont {
    async renderDaftarAnggota(_req, resp) {
        try {
            let anggotaAr = await admin_1.admin.dao.anggota.cariAnggota('---', 0);
            let jml = (await admin_1.admin.dao.anggota.jmlCariAnggota('---')).jumlah;
            let hal = admin_1.admin.render.daftarAnggota.render(anggotaAr, 0, jml, '---', RouterKons_1.RouterKOns.daftarAnggotaFilter);
            resp.status(200).send(hal);
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async renderHalBerandaEdit(_req, resp) {
        try {
            let id = parseInt(_req.params.id);
            let anggotaAr = await admin_1.admin.dao.anggota.lihat(id);
            let anggota = anggotaAr[0];
            let hal;
            //pasangan info
            if (anggota.rel_id > 0) {
                let pasAr = await admin_1.admin.dao.pasangan.lihatPasangan(anggota.id, anggota.rel_id);
                let pas = pasAr[0];
                anggota.pas = pas;
                anggota.rel = (await admin_1.admin.dao.rel.byId(anggota.rel_id))[0];
                anggota.anak = (await admin_1.admin.dao.anak.daftarAnak(anggota.rel_id));
            }
            else {
                anggota.anak = [];
            }
            hal = admin_1.admin.render.editBeranda.render(anggota);
            resp.status(200).send(hal);
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async renderEditProfile(_req, resp) {
        try {
            let id = parseInt(_req.params.id);
            let anggotaAr = await admin_1.admin.dao.anggota.lihat(id);
            let anggota = anggotaAr[0];
            let hal = admin_1.admin.render.editProfileAnggota.render(anggota);
            resp.status(200).send(hal);
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async renderDaftarCalonAnak(_req, resp) {
        let anggotaAr = await admin_1.admin.dao.anggota.cariAnggota("-", 0);
        let jml = (await admin_1.admin.dao.anggota.jmlCariAnggota("---")).jumlah;
        let anggota = (await admin_1.admin.dao.anggota.lihat(parseInt(_req.params.id)))[0];
        let hal = admin_1.admin.render.pilihAnggotaGenerik.render(anggotaAr, anggota, RouterKons_1.RouterKOns.editOrtu, RouterKons_1.RouterKOns.daftarCalonAnakFilter, 'pilih anak', "-", jml, 0);
        resp.status(200).send(hal);
    }
    async renderDaftarCalonAnakCari(_req, resp) {
        let id = parseInt(_req.params.id);
        let kunci = decodeURI(_req.params.kunci);
        let anggota = (await admin_1.admin.dao.anggota.lihat(id))[0];
        let select = admin_1.admin.dao.anggota.select_profile;
        let where = admin_1.admin.dao.anggota.where_semua;
        let order = admin_1.admin.dao.anggota.order_nama;
        let offsetLog = parseInt(_req.params.hal);
        let jml = (await admin_1.admin.dao.anggota.jmlCariAnggota(kunci)).jumlah;
        let kunciSql = '%' + kunci + '%';
        if (!kunci || "-" == kunci) {
            where = admin_1.admin.dao.anggota.where_semua;
        }
        else {
            where = admin_1.admin.dao.anggota.where_cari;
        }
        //fiter bani
        // where += " AND bani = ? "
        let anggotaAr = await admin_1.admin.dao.anggota.baca(select, where, offsetLog * Config_1.config.jmlPerHal, order, [kunciSql, kunciSql, (0, SessionData_1.session)(_req).id]);
        let hal = admin_1.admin.render.pilihAnggotaGenerik.render(anggotaAr, anggota, RouterKons_1.RouterKOns.editOrtu, RouterKons_1.RouterKOns.daftarCalonAnakFilter, 'pilih anak', kunci, jml, offsetLog);
        resp.status(200).send(hal);
    }
    async renderDaftarAnggotaCari(_req, resp) {
        try {
            let kunci = decodeURI(_req.params.kunci);
            let hal = parseInt(_req.params.hal);
            let jml = (await admin_1.admin.dao.anggota.jmlCariAnggota(kunci)).jumlah;
            let offsetAbs = hal * Config_1.config.jmlPerHal;
            let anggotaAr = await admin_1.admin.dao.anggota.cariAnggota(kunci, offsetAbs);
            let str = admin_1.admin.render.daftarAnggota.render(anggotaAr, hal, jml, kunci, RouterKons_1.RouterKOns.daftarAnggotaFilter);
            resp.status(200).send(str);
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async renderPendaftaranAnggotaBaru(_req, resp) {
        try {
            let hal = admin_1.admin.render.anggotaBaru.render();
            resp.status(200).send(hal);
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    //POST
    //====
    async gambarTulisDisk(p, data) {
        return new Promise((resolve, reject) => {
            fs_1.default.writeFile(p, data, (err) => {
                if (err) {
                    console.error(err);
                    reject(err);
                }
                else {
                    resolve();
                }
            });
        });
    }
    async upload(req, resp) {
        try {
            // console.debug('gambar upload');
            let buf;
            let id = parseInt(req.params.id);
            let foto = {
                gbr_baru: req.body.gbr_baru,
                thumb_baru: req.body.thumb_baru,
                nama_gbr: req.body.nama_gbr,
                nama_thumb: req.body.nama_thumb
            };
            //simpan gbr besar
            buf = Buffer.from(foto.gbr_baru, 'base64');
            await admin_1.admin.cont.anggota.gambarTulisDisk(Util_1.util.baseDir + Kons_1.kons.folder_upload + foto.nama_gbr, buf);
            //simpan gambar kecil
            buf = Buffer.from(foto.thumb_baru, 'base64');
            await admin_1.admin.cont.anggota.gambarTulisDisk(Util_1.util.baseDir + Kons_1.kons.folder_upload + foto.nama_thumb, buf);
            await admin_1.admin.dao.anggota.update({
                thumb: Kons_1.kons.folder_download + foto.nama_thumb,
                foto: Kons_1.kons.folder_download + foto.nama_gbr
            }, id);
            resp.status(200).send(JSON.stringify({
                url_thumb: Kons_1.kons.folder_download + foto.nama_thumb,
                url_gbr: Kons_1.kons.folder_download + foto.nama_gbr
            }));
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async daftarAnak(_req, resp) {
        try {
            let id = parseInt(_req.params.id);
            let anggota = (await admin_1.admin.dao.anggota.lihat(id))[0];
            let hasil = [];
            if (anggota.rel_id == 0) {
                hasil = [];
            }
            else {
                hasil = await admin_1.admin.dao.anak.daftarAnak(anggota.rel_id);
            }
            resp.status(200).send(JSON.stringify(hasil));
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async pendaftaranAnggota(_req, resp) {
        try {
            let data = {
                nama: Validator_1.v.escape(_req.body.nama),
                nama_lengkap: Validator_1.v.escape(_req.body.nama_lengkap),
                alamat: Validator_1.v.escape(_req.body.alamat),
                fb: Validator_1.v.escape(_req.body.fb),
                wa: Validator_1.v.escape(_req.body.wa),
                instagram: Validator_1.v.escape(_req.body.instagram),
                jkl: Validator_1.v.escape(_req.body.jkl),
                tgl_lahir: Validator_1.v.escape(_req.body.tgl_lahir),
                tgl_meninggal: Validator_1.v.escape(_req.body.tgl_meninggal),
                foto: Validator_1.v.escape(_req.body.foto),
                thumb: Validator_1.v.escape(_req.body.thumb),
                bani: (0, SessionData_1.session)(_req).id
            };
            let hasil = await admin_1.admin.dao.anggota.baru(data);
            resp.status(200).send(hasil.insertId + '');
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async editProfile(_req, resp) {
        try {
            let data = {
                // id: parseInt(_req.params.id),
                nama: Validator_1.v.escape(_req.body.nama),
                nama_lengkap: Validator_1.v.escape(_req.body.nama_lengkap),
                alamat: Validator_1.v.escape(_req.body.alamat),
                fb: Validator_1.v.escape(_req.body.fb),
                wa: Validator_1.v.escape(_req.body.wa),
                instagram: Validator_1.v.escape(_req.body.instagram),
                jkl: Validator_1.v.escape(_req.body.jkl),
                tgl_lahir: Validator_1.v.escape(_req.body.tgl_lahir),
                tgl_meninggal: Validator_1.v.escape(_req.body.tgl_meninggal)
            };
            let id = parseInt(_req.params.id);
            //TODO:[ux] validate
            let hasil = await admin_1.admin.dao.anggota.update(data, id);
            resp.status(200).send(JSON.stringify(hasil));
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async editRel(_req, resp) {
        try {
            let id = parseInt(_req.params.id);
            let id2 = parseInt(_req.params.id2);
            // console.debug('update rel, id: ' + id + '/rel id: ' + id2);
            await admin_1.admin.dao.anggota.updateRel(id, id2);
            resp.status(200).send('');
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async editOrtu(_req, resp) {
        try {
            let id = parseInt(_req.params.id);
            let idOrtu = parseInt(_req.params.id2);
            await admin_1.admin.dao.ortu.updateOrtu(id, idOrtu);
            resp.status(200).send('');
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
    async hapus(_req, resp) {
        try {
            await admin_1.admin.dao.anggota.hapus(parseInt(_req.params.id));
            resp.status(200).send('');
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
}
exports.AnggotaCont = AnggotaCont;
