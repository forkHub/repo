"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Cont = void 0;
const AnggotaCont_1 = require("./AnggotaCont");
const Pasangan_1 = require("./Pasangan");
const PasanganCont_1 = require("./PasanganCont");
class Cont {
    anggota = new AnggotaCont_1.AnggotaCont();
    relasi = new Pasangan_1.Pasangan();
    relasi2 = new PasanganCont_1.PasanganCont();
}
exports.Cont = Cont;
