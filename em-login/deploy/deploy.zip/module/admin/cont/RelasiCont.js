"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelasiCont = void 0;
const RouterKons_1 = require("../../silsilah/RouterKons");
const SilsilahModule_1 = require("../../silsilah/SilsilahModule");
const Util_1 = require("../../Util");
class RelasiCont {
    //TODO: dipindah ke pasangan cont atau di rename
    async renderTambahPasangan(_req, resp) {
        try {
            let id = parseInt(_req.params.id);
            let kunci = '-';
            let jmlAbs = 0;
            let hal = 0;
            // let where: string = sm.dao.anggota.where_jkl;
            let jkl = '';
            // let data: any[] = [];
            let offset = 0;
            //parameter bila ada
            if (_req.params.kunci)
                kunci = _req.params.kunci;
            if (_req.params.hal)
                hal = parseInt(_req.params.hal);
            //buat relasi bila belum ada
            let anggota = (await SilsilahModule_1.sm.dao.anggota.lihat(id))[0];
            if (anggota.rel_id == 0) {
                anggota.rel_id = (await SilsilahModule_1.sm.dao.rel.baru()).insertId;
                await SilsilahModule_1.sm.dao.anggota.updateRel(anggota.id, anggota.rel_id);
            }
            //daftar anggota
            if (anggota.jkl == 'l') {
                jkl = 'p';
            }
            else {
                jkl = 'l';
            }
            // if (("-" != kunci)) {
            // 	where = " WHERE jkl = ? AND (nama LIKE ? OR nama_lengkap LIKE ?)";
            // 	data = [jkl, '%' + kunci + '%', '%' + kunci + '%'];
            // }
            // else {
            // 	where = " WHERE jkl = ? ";
            // 	data = [jkl];
            // }
            //filter bani
            // where += ` AND bani = ? `;
            // data.push(session(_req).id);
            let anggotaAr = await SilsilahModule_1.sm.dao.pasangan.daftarCalonPasangan(kunci, offset, jkl);
            jmlAbs = (await SilsilahModule_1.sm.dao.pasangan.jmlCariPasangan(kunci, offset, jkl));
            let str = SilsilahModule_1.sm.admin.render.pilihAnggotaGenerik.render(anggotaAr, anggota, RouterKons_1.RouterKOns.p_anggota_id_rel_edit_id, RouterKons_1.RouterKOns.halCariPasanganFilter, 'pilih pasangan:', kunci, jmlAbs, hal);
            resp.status(200).send(str);
        }
        catch (e) {
            Util_1.util.respError(resp, e);
        }
    }
}
exports.RelasiCont = RelasiCont;
