"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.admin = exports.Admin = void 0;
const cont_1 = require("./cont/cont");
const Dao_1 = require("./dao/Dao");
const Render_1 = require("./render/Render");
const Router_1 = require("./Router");
class Admin {
    cont = new cont_1.Cont();
    render = new Render_1.Render();
    router = new Router_1.Router();
    dao = new Dao_1.Dao();
}
exports.Admin = Admin;
exports.admin = new Admin();
