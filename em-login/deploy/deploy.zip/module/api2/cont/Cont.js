"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cont = void 0;
const AnakCont_1 = require("./AnakCont");
const AnggotaCont_1 = require("./AnggotaCont");
class Cont {
    anak = new AnakCont_1.AnakCont();
    anggota = new AnggotaCont_1.AnggotaCont();
}
exports.cont = new Cont();
