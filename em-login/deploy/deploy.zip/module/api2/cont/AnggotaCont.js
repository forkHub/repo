"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnggotaCont = void 0;
const Silsilah_1 = require("../../silsilah/Silsilah");
class AnggotaCont {
    async lihatProfileAnggota(id) {
        let anggota = await Silsilah_1.sm.ent.anggota.populate(id);
        await Silsilah_1.sm.ent.kerabat.muat(anggota);
        return anggota;
    }
    async lihatAnggota(id) {
        let anggota = await Silsilah_1.sm.ent.anggota.populate(id);
        await Silsilah_1.sm.ent.kerabat.muat(anggota);
        return anggota;
    }
}
exports.AnggotaCont = AnggotaCont;
