"use strict";
class AuthCont {
}
