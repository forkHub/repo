"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnggotaDao = void 0;
const Sql_1 = require("../../Sql");
const Query_1 = require("./Query");
class AnggotaDao {
    async lihatById(id) {
        let query = Query_1.queryObj.selectAnggota + `
			WHERE id = ?
            LIMIT 1
		`;
        let hasil = await Sql_1.sql.query(query, [id]);
        if (hasil && hasil.length > 0) {
            return hasil;
        }
        else {
            console.warn('hasil tidak ditemukan:');
            console.log('query ' + query);
            return [];
        }
    }
}
exports.AnggotaDao = AnggotaDao;
