"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PasanganEnt = void 0;
class PasanganEnt {
}
exports.PasanganEnt = PasanganEnt;
