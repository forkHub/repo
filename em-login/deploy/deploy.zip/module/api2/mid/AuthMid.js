"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthMid = void 0;
const Config_1 = require("../../Config");
const SessionData_1 = require("../../SessionData");
// import { sm } from "../../silsilah/SilsilahModule";
class AuthMid {
    checkAuthSession(req, resp, next) {
        console.log('check status login:');
        console.log((0, SessionData_1.session)(req).statusLogin);
        if ((0, SessionData_1.session)(req).statusLogin) {
            if (Config_1.config.loginCheck) {
                // console.log(sm.session(req));
                resp.status(401).send('');
            }
            else {
                next();
            }
        }
        else {
            next();
        }
    }
}
exports.AuthMid = AuthMid;
