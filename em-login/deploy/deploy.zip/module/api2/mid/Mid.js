"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mid = void 0;
const AuthMid_1 = require("./AuthMid");
class Mid {
    _authMid = new AuthMid_1.AuthMid();
    get authMid() {
        return this._authMid;
    }
}
exports.mid = new Mid();
