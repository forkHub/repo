"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RouterAPI2Kons = void 0;
class RouterAPI2Kons {
    //auth
    static api_auth_login = "/api/auth/login";
    static api_auth_logout = "/api/auth/logout";
    //anggota
    static api_anggota_lihat = "/api/anggota/lihat";
    static api_anggota_daftar = "/api/anggota/daftar";
    static api_anggota_edit = "/api/anggota/edit";
    static api_anggota_hapus = "/api/anggota/hapus";
    static api_anggota_update = "/api/anggota/update";
    //anggota update
    //profile
    static api_profile_lihat = "/api/profile/lihat"; //sama dengan anggota lihat
    //kerabat
    static api_kerabat_lihat = "/api/kerabat/lihat";
    //anak
    static api_anak_daftar = "/api/anak/daftar";
    static api_anak_edit = "/api/anak/edit";
    static api_anak_hapus = "/api/anak/hapus";
    static api_anak_update = "/api/anak/update";
    //ortu
    static api_ortu_daftar = "/api/ortu/daftar";
    static api_ortu_edit = "/api/ortu/edit";
    static api_ortu_hapus = "/api/ortu/hapus";
    static api_ortu_update = "/api/ortu/update";
}
exports.RouterAPI2Kons = RouterAPI2Kons;
