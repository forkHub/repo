"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnggotaRouter = void 0;
const Util_1 = require("../../Util");
const Cont_1 = require("../cont/Cont");
const Mid_1 = require("../mid/Mid");
const RouterAPI2Kons_1 = require("../RouterAPI2Kons");
class AnggotaRouter {
    router(router) {
        router.post(RouterAPI2Kons_1.RouterAPI2Kons.api_profile_lihat, Mid_1.mid.authMid.checkAuthSession, (_req, resp) => {
            try {
                console.log('profile lihat');
                let id = parseInt(_req.body.id);
                Cont_1.cont.anggota.lihatProfileAnggota(id).then((anggota) => {
                    resp.status(200).send(JSON.stringify(anggota));
                }).catch((e) => {
                    Util_1.util.respError(resp, e);
                });
            }
            catch (e) {
                Util_1.util.respError(resp, e);
            }
        });
        router.post(RouterAPI2Kons_1.RouterAPI2Kons.api_anggota_lihat, Mid_1.mid.authMid.checkAuthSession, (_req, resp) => {
            try {
                console.log('lihat anggota:');
                let id = parseInt(_req.body.id);
                console.log('id: ' + id);
                Cont_1.cont.anggota.lihatAnggota(id).then((anggota) => {
                    resp.status(200).send(JSON.stringify(anggota));
                }).catch((e) => {
                    Util_1.util.respError(resp, e);
                });
            }
            catch (e) {
                Util_1.util.respError(resp, e);
            }
        });
    }
}
exports.AnggotaRouter = AnggotaRouter;
