"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configDB = void 0;
exports.configDB = {
    host: 'localhost',
    user: 'root',
    pass: '',
    db: 'silsilah',
    port: 3306,
    email: {
        service: '',
        user: '',
        pass: '',
        from: 'jangan_dibalas@pasartamel.com'
    },
    admin: {
        id: 'admin',
        pass: 'admin123!'
    }
};
