"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sm = void 0;
const BerandaCont_1 = require("./BerandaCont");
const Dao_1 = require("./dao/Dao");
const Ent_1 = require("./ent/Ent");
const HalProfile_1 = require("./HalProfile");
const HalSilsilah_1 = require("./HalSilsilah");
const Router_1 = require("./Router");
class SM {
    router = new Router_1.Router();
    dao = new Dao_1.Dao();
    ent = new Ent_1.Entity();
    halSilsilah = new HalSilsilah_1.HalSilsilah();
    halProfile = new HalProfile_1.HalProfile();
    berandaCont = new BerandaCont_1.BerandaCont();
}
exports.sm = new SM();
