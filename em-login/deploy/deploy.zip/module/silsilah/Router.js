"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Router = void 0;
const express_1 = __importDefault(require("express"));
const Auth_1 = require("../auth/Auth");
const RouterKons_1 = require("./RouterKons");
const Silsilah_1 = require("./Silsilah");
class Router {
    router = express_1.default.Router();
    impl() {
        this.router.get("/", Auth_1.auth.cont.checkAuthGet, Silsilah_1.sm.berandaCont.renderBeranda);
        //#web
        this.router.get(RouterKons_1.RouterKOns.berandaId, Auth_1.auth.cont.checkAuthGet, Silsilah_1.sm.berandaCont.renderBerandaId);
        this.router.get(RouterKons_1.RouterKOns.lihatProfile, Auth_1.auth.cont.checkAuthGet, Silsilah_1.sm.berandaCont.lihatProfileAnggota);
    }
}
exports.Router = Router;
