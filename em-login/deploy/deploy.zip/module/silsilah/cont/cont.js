"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Cont = void 0;
const BerandaCont_1 = require("./BerandaCont");
class Cont {
    beranda = new BerandaCont_1.BerandaCont();
}
exports.Cont = Cont;
