"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrtuDao = void 0;
const Sql_1 = require("../../Sql");
class OrtuDao {
    async lihatOrtu(relId) {
        return await Sql_1.sql.query(`
			SELECT *
			FROM sl_anggota
			WHERE rel_id = ?
		`, [relId]);
    }
}
exports.OrtuDao = OrtuDao;
