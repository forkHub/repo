"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PasanganDao = void 0;
const Sql_1 = require("../../Sql");
class PasanganDao {
    async lihatPasangan(id, relId) {
        return await Sql_1.sql.query(`
			SELECT *
			FROM sl_anggota
			WHERE id != ?  AND rel_id = ? 
		`, [id, relId]);
    }
}
exports.PasanganDao = PasanganDao;
