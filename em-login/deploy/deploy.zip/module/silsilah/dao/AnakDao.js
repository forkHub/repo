"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnakDao = void 0;
const Sql_1 = require("../../Sql");
class AnakDao {
    async daftarAnak(rel_id) {
        let hasil = await Sql_1.sql.query(`
			SELECT *
			FROM sl_anggota
			WHERE ortu_id = ?
			ORDER BY tgl_lahir`, [rel_id]);
        return hasil;
    }
}
exports.AnakDao = AnakDao;
