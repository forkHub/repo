"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnggotaDao = void 0;
const Sql_1 = require("../../Sql");
const Config_1 = require("../../Config");
class AnggotaDao {
    //TODO: [ref] dibuat lebih sepesifik
    async baca(select, where, offset, order, data) {
        offset = parseInt(offset + ''); //validate number
        let query = `
			SELECT ${select}
			FROM sl_anggota
			${where}
			${order}
			LIMIT ${Config_1.config.jmlPerHal}
			OFFSET ${offset}
		`;
        let hasil = await Sql_1.sql.query(query, data);
        return hasil;
    }
    async lihat(id) {
        return await Sql_1.sql.query(`
			SELECT *
			FROM sl_anggota
			WHERE id = ?
		`, [id]);
    }
}
exports.AnggotaDao = AnggotaDao;
