"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RouterKOns = void 0;
class RouterKOns {
    //web
    static lihatProfile = "/sm/beranda/lihat/:id";
    static berandaId = "/sm/beranda/:id";
}
exports.RouterKOns = RouterKOns;
