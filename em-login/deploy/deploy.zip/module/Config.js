"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
//NOTE: FINAL
exports.config = {
    jmlPerHal: 5,
    dev: false,
    judul: 'silsilah',
    api: true,
    loginCheck: true,
};
